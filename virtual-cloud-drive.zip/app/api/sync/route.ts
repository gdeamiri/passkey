import { type NextRequest, NextResponse } from "next/server"

// Временное хранилище для демонстрации (в реальном приложении используйте базу данных)
const cloudStorage = new Map<string, any>()

export async function POST(request: NextRequest) {
  try {
    const { userId, devices, timestamp } = await request.json()
    const authHeader = request.headers.get("authorization")

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.split(" ")[1]

    // Простая проверка токена (в реальном приложении используйте JWT)
    if (token !== userId) {
      return NextResponse.json({ error: "Invalid token" }, { status: 401 })
    }

    // Сохраняем зашифрованные данные
    cloudStorage.set(userId, {
      devices,
      timestamp,
      lastSync: new Date().toISOString(),
    })

    return NextResponse.json({
      success: true,
      message: "Data synced successfully",
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Sync error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    const url = new URL(request.url)
    const userId = url.pathname.split("/").pop()
    const authHeader = request.headers.get("authorization")

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.split(" ")[1]

    if (token !== userId) {
      return NextResponse.json({ error: "Invalid token" }, { status: 401 })
    }

    const userData = cloudStorage.get(userId)

    if (!userData) {
      return NextResponse.json({ error: "No data found" }, { status: 404 })
    }

    return NextResponse.json(userData)
  } catch (error) {
    console.error("Load error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
