import { type NextRequest, NextResponse } from "next/server"

// Временное хранилище для демонстрации
const cloudStorage = new Map<string, any>()

export async function GET(request: NextRequest, { params }: { params: { userId: string } }) {
  try {
    const { userId } = params
    const authHeader = request.headers.get("authorization")

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const token = authHeader.split(" ")[1]

    if (token !== userId) {
      return NextResponse.json({ error: "Invalid token" }, { status: 401 })
    }

    const userData = cloudStorage.get(userId)

    if (!userData) {
      return NextResponse.json({
        devices: "[]",
        timestamp: new Date().toISOString(),
        lastSync: new Date().toISOString(),
      })
    }

    return NextResponse.json(userData)
  } catch (error) {
    console.error("Load error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
