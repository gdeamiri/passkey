import { NextResponse } from "next/server"

export async function GET() {
  try {
    // Генерируем установочный скрипт для Windows
    const installerScript = `
@echo off
echo ========================================
echo Cloud Security Key Installer v1.0
echo ========================================
echo.

REM Проверяем права администратора
net session >nul 2>&1
if %errorLevel% == 0 (
    echo Права администратора подтверждены.
) else (
    echo ОШИБКА: Требуются права администратора!
    echo Запустите установщик от имени администратора.
    pause
    exit /b 1
)

echo Создание директорий...
mkdir "%ProgramFiles%\\CloudSecurityKey" 2>nul
mkdir "%ProgramFiles%\\CloudSecurityKey\\drivers" 2>nul
mkdir "%APPDATA%\\CloudSecurityKey" 2>nul

echo Копирование файлов...
REM Здесь будут команды копирования файлов приложения

echo Установка драйверов...
REM Установка виртуального USB драйвера
pnputil /add-driver "%~dp0drivers\\cloudkey.inf" /install

echo Регистрация службы...
sc create "CloudSecurityKey" binPath= "%ProgramFiles%\\CloudSecurityKey\\CloudSecurityKey.exe" start= auto
sc description "CloudSecurityKey" "Облачный эмулятор USB Security Key"

echo Создание ярлыков...
powershell -Command "\\$WshShell = New-Object -comObject WScript.Shell; \\$Shortcut = \\$WshShell.CreateShortcut('\\$env:USERPROFILE\\Desktop\\Cloud Security Key.lnk'); \\$Shortcut.TargetPath = '%ProgramFiles%\\CloudSecurityKey\\CloudSecurityKey.exe'; \\$Shortcut.Save()"

echo Настройка автозапуска...
reg add "HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Run" /v "CloudSecurityKey" /t REG_SZ /d "%ProgramFiles%\\CloudSecurityKey\\CloudSecurityKey.exe" /f

echo.
echo ========================================
echo Установка завершена успешно!
echo ========================================
echo.
echo Приложение будет запущено автоматически при следующем входе в систему.
echo Вы также можете запустить его с рабочего стола.
echo.
echo Для настройки откройте: ${process.env.NEXT_PUBLIC_APP_URL}
echo.
pause

REM Запускаем приложение
start "" "%ProgramFiles%\\CloudSecurityKey\\CloudSecurityKey.exe"
`

    // Возвращаем файл как скачиваемый
    return new NextResponse(installerScript, {
      status: 200,
      headers: {
        "Content-Type": "application/octet-stream",
        "Content-Disposition": "attachment; filename=CloudSecurityKey_Setup.bat",
      },
    })
  } catch (error) {
    console.error("Ошибка генерации установщика:", error)
    return NextResponse.json({ error: "Ошибка генерации установщика" }, { status: 500 })
  }
}
