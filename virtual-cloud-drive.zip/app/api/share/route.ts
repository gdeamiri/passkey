import { type NextRequest, NextResponse } from "next/server"

// Хранилище для общих ключей
const sharedKeys = new Map<string, any>()

export async function POST(request: NextRequest) {
  try {
    const { deviceId, ownerEmail, shareWithEmail, permissions } = await request.json()

    const shareId = `share-${Math.random().toString(36).substr(2, 9)}`

    sharedKeys.set(shareId, {
      deviceId,
      ownerEmail,
      shareWithEmail,
      permissions: permissions || ["read", "authenticate"],
      createdAt: new Date().toISOString(),
      isActive: true,
    })

    return NextResponse.json({
      success: true,
      shareId,
      shareUrl: `${process.env.NEXT_PUBLIC_APP_URL}/share/${shareId}`,
    })
  } catch (error) {
    console.error("Share error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    const url = new URL(request.url)
    const shareId = url.searchParams.get("shareId")
    const userEmail = url.searchParams.get("userEmail")

    if (!shareId || !userEmail) {
      return NextResponse.json({ error: "Missing parameters" }, { status: 400 })
    }

    const shareData = sharedKeys.get(shareId)

    if (!shareData || !shareData.isActive) {
      return NextResponse.json({ error: "Share not found or inactive" }, { status: 404 })
    }

    if (shareData.shareWithEmail !== userEmail) {
      return NextResponse.json({ error: "Access denied" }, { status: 403 })
    }

    return NextResponse.json(shareData)
  } catch (error) {
    console.error("Share access error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
