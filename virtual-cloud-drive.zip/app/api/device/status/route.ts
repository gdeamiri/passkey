import { type NextRequest, NextResponse } from "next/server"

// Хранилище статусов устройств
const deviceStatuses = new Map<string, any>()

export async function POST(request: NextRequest) {
  try {
    const { deviceId, status, userId } = await request.json()
    const authHeader = request.headers.get("authorization")

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Обновляем статус устройства
    deviceStatuses.set(deviceId, {
      status,
      userId,
      lastUpdate: new Date().toISOString(),
      isActive: status === "connected",
    })

    return NextResponse.json({
      success: true,
      deviceId,
      status,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Device status error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    const url = new URL(request.url)
    const deviceId = url.searchParams.get("deviceId")

    if (!deviceId) {
      return NextResponse.json({ error: "Device ID required" }, { status: 400 })
    }

    const deviceStatus = deviceStatuses.get(deviceId)

    if (!deviceStatus) {
      return NextResponse.json({
        status: "offline",
        lastUpdate: null,
        isActive: false,
      })
    }

    return NextResponse.json(deviceStatus)
  } catch (error) {
    console.error("Device status fetch error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
