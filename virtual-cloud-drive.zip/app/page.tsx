"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Progress } from "@/components/ui/progress"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import {
  Usb,
  Shield,
  Download,
  CheckCircle,
  Settings,
  Key,
  Cloud,
  Users,
  Play,
  Square,
  Share2,
  UserPlus,
  Copy,
  RefreshCw,
  Globe,
  Fingerprint,
  LogIn,
  LogOut,
} from "lucide-react"

interface VirtualDevice {
  id: string
  name: string
  status: "connected" | "disconnected" | "authenticating"
  lastUsed: Date
  totalAuth: number
  isShared: boolean
  sharedWith: string[]
}

interface User {
  id: string
  name: string
  email: string
  avatar: string
}

export default function CloudSecurityKeyApp() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [isInstalled, setIsInstalled] = useState(false)
  const [isRunning, setIsRunning] = useState(false)
  const [devices, setDevices] = useState<VirtualDevice[]>([])
  const [installProgress, setInstallProgress] = useState(0)
  const [systemStatus, setSystemStatus] = useState("ready")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [currentUser, setCurrentUser] = useState<User | null>(null)
  const [sharedUsers, setSharedUsers] = useState<User[]>([])
  const [shareEmail, setShareEmail] = useState("")
  const [syncStatus, setSyncStatus] = useState("synced")
  const [lastSynced, setLastSynced] = useState<Date | null>(null)

  const [encryptionKey, setEncryptionKey] = useState("")
  const [isEncrypted, setIsEncrypted] = useState(false)
  const [cloudStatus, setCloudStatus] = useState("disconnected")

  useEffect(() => {
    // Проверяем установку и авторизацию
    const installed = localStorage.getItem("cloudKeyInstalled")
    if (installed) {
      setIsInstalled(true)

      const user = localStorage.getItem("currentUser")
      if (user) {
        setIsLoggedIn(true)
        setCurrentUser(JSON.parse(user))
        loadDevices()
        loadSharedUsers()
      }
    }
  }, [])

  const loadDevices = () => {
    const savedDevices = localStorage.getItem("cloudDevices")
    if (savedDevices) {
      setDevices(
        JSON.parse(savedDevices).map((device: any) => ({
          ...device,
          lastUsed: new Date(device.lastUsed),
        })),
      )
    }
  }

  const loadSharedUsers = () => {
    // Загружаем пользователей, с которыми расшарены ключи
    const users = [
      {
        id: "user1",
        name: "Алексей К.",
        email: "alex@example.com",
        avatar: "",
      },
      {
        id: "user2",
        name: "Мария С.",
        email: "maria@example.com",
        avatar: "",
      },
    ]
    setSharedUsers(users)
  }

  // Функции шифрования
  const encryptData = async (data: string) => {
    if (!encryptionKey) return data

    try {
      const encoder = new TextEncoder()
      const keyMaterial = await crypto.subtle.importKey(
        "raw",
        encoder.encode(encryptionKey),
        { name: "PBKDF2" },
        false,
        ["deriveBits", "deriveKey"],
      )

      const key = await crypto.subtle.deriveKey(
        {
          name: "PBKDF2",
          salt: encoder.encode("cloudkey-salt"),
          iterations: 100000,
          hash: "SHA-256",
        },
        keyMaterial,
        { name: "AES-GCM", length: 256 },
        true,
        ["encrypt", "decrypt"],
      )

      const iv = crypto.getRandomValues(new Uint8Array(12))
      const encrypted = await crypto.subtle.encrypt({ name: "AES-GCM", iv: iv }, key, encoder.encode(data))

      return {
        iv: Array.from(iv),
        data: Array.from(new Uint8Array(encrypted)),
      }
    } catch (error) {
      console.error("Ошибка шифрования:", error)
      return data
    }
  }

  const decryptData = async (encryptedData: any) => {
    if (!encryptionKey || typeof encryptedData === "string") return encryptedData

    try {
      const encoder = new TextEncoder()
      const decoder = new TextDecoder()

      const keyMaterial = await crypto.subtle.importKey(
        "raw",
        encoder.encode(encryptionKey),
        { name: "PBKDF2" },
        false,
        ["deriveBits", "deriveKey"],
      )

      const key = await crypto.subtle.deriveKey(
        {
          name: "PBKDF2",
          salt: encoder.encode("cloudkey-salt"),
          iterations: 100000,
          hash: "SHA-256",
        },
        keyMaterial,
        { name: "AES-GCM", length: 256 },
        true,
        ["encrypt", "decrypt"],
      )

      const iv = new Uint8Array(encryptedData.iv)
      const data = new Uint8Array(encryptedData.data)

      const decrypted = await crypto.subtle.decrypt({ name: "AES-GCM", iv: iv }, key, data)

      return decoder.decode(decrypted)
    } catch (error) {
      console.error("Ошибка расшифровки:", error)
      return encryptedData
    }
  }

  const syncToCloud = async () => {
    if (!currentUser || !encryptionKey) return

    setCloudStatus("syncing")

    try {
      // Шифруем данные перед отправкой
      const encryptedDevices = await encryptData(JSON.stringify(devices))

      // Симуляция отправки на сервер
      const response = await fetch("/api/sync", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${currentUser.id}`,
        },
        body: JSON.stringify({
          userId: currentUser.id,
          devices: encryptedDevices,
          timestamp: new Date().toISOString(),
        }),
      })

      if (response.ok) {
        setCloudStatus("connected")
        setLastSynced(new Date())
        setSyncStatus("synced")
      } else {
        setCloudStatus("error")
      }
    } catch (error) {
      console.error("Ошибка синхронизации:", error)
      setCloudStatus("error")
    }
  }

  const loadFromCloud = async () => {
    if (!currentUser || !encryptionKey) return

    try {
      const response = await fetch(`/api/sync/${currentUser.id}`, {
        headers: {
          Authorization: `Bearer ${currentUser.id}`,
        },
      })

      if (response.ok) {
        const data = await response.json()
        const decryptedDevices = await decryptData(data.devices)

        if (typeof decryptedDevices === "string") {
          const parsedDevices = JSON.parse(decryptedDevices).map((device: any) => ({
            ...device,
            lastUsed: new Date(device.lastUsed),
          }))
          setDevices(parsedDevices)
          setCloudStatus("connected")
        }
      }
    } catch (error) {
      console.error("Ошибка загрузки из облака:", error)
      setCloudStatus("error")
    }
  }

  const installVirtualDriver = async () => {
    setInstallProgress(0)

    // Симуляция установки драйвера
    const steps = [
      "Загрузка виртуального USB драйвера...",
      "Установка FIDO2 эмулятора...",
      "Настройка облачного хранилища...",
      "Регистрация HID устройства...",
      "Настройка WebAuthn интерфейса...",
      "Создание виртуальной флешки...",
      "Настройка облачной синхронизации...",
      "Завершение установки...",
    ]

    for (let i = 0; i < steps.length; i++) {
      await new Promise((resolve) => setTimeout(resolve, 800))
      setInstallProgress(((i + 1) / steps.length) * 100)
    }

    setIsInstalled(true)
    localStorage.setItem("cloudKeyInstalled", "true")
  }

  const login = () => {
    if (!email || !password) return

    // Используем переменную окружения для ключа шифрования
    setEncryptionKey(process.env.ENCRYPTION_KEY || password)
    setIsEncrypted(true)

    // Симуляция входа
    const user: User = {
      id: "user123",
      name: email.split("@")[0],
      email: email,
      avatar: "",
    }

    setCurrentUser(user)
    setIsLoggedIn(true)
    localStorage.setItem("currentUser", JSON.stringify(user))

    // Создаем первое виртуальное устройство
    const defaultDevice: VirtualDevice = {
      id: "vsk-" + Math.random().toString(36).substr(2, 9),
      name: "Cloud Security Key #1",
      status: "disconnected",
      lastUsed: new Date(),
      totalAuth: 0,
      isShared: false,
      sharedWith: [],
    }

    setDevices([defaultDevice])
    localStorage.setItem("cloudDevices", JSON.stringify([defaultDevice]))

    // Загружаем пользователей для шаринга
    loadSharedUsers()

    // Устанавливаем время синхронизации
    setLastSynced(new Date())

    setCloudStatus("connected")
    loadFromCloud()
  }

  const logout = () => {
    setIsLoggedIn(false)
    setCurrentUser(null)
    localStorage.removeItem("currentUser")
  }

  const startVirtualDevice = (deviceId: string) => {
    setDevices((prev) => prev.map((device) => (device.id === deviceId ? { ...device, status: "connected" } : device)))
    setIsRunning(true)
    setSystemStatus("running")

    // Симуляция работы устройства
    simulateDeviceActivity(deviceId)
  }

  const stopVirtualDevice = (deviceId: string) => {
    setDevices((prev) =>
      prev.map((device) => (device.id === deviceId ? { ...device, status: "disconnected" } : device)),
    )
    setIsRunning(false)
    setSystemStatus("ready")
  }

  const simulateDeviceActivity = (deviceId: string) => {
    // Симуляция активности устройства
    const interval = setInterval(() => {
      if (Math.random() > 0.7) {
        // Случайная аутентификация
        setDevices((prev) =>
          prev.map((device) =>
            device.id === deviceId
              ? {
                  ...device,
                  status: "authenticating",
                  lastUsed: new Date(),
                  totalAuth: device.totalAuth + 1,
                }
              : device,
          ),
        )

        setTimeout(() => {
          setDevices((prev) =>
            prev.map((device) => (device.id === deviceId ? { ...device, status: "connected" } : device)),
          )

          // Обновляем время синхронизации
          setSyncStatus("syncing")
          setTimeout(() => {
            setSyncStatus("synced")
            setLastSynced(new Date())
          }, 1500)
        }, 2000)
      }
    }, 5000)

    return () => clearInterval(interval)
  }

  const createNewDevice = () => {
    const newDevice: VirtualDevice = {
      id: "vsk-" + Math.random().toString(36).substr(2, 9),
      name: `Cloud Security Key #${devices.length + 1}`,
      status: "disconnected",
      lastUsed: new Date(),
      totalAuth: 0,
      isShared: false,
      sharedWith: [],
    }

    setDevices((prev) => [...prev, newDevice])
    localStorage.setItem("cloudDevices", JSON.stringify([...devices, newDevice]))

    // Автоматическая синхронизация с облаком
    syncToCloud()
  }

  const shareDevice = async (deviceId: string) => {
    if (!shareEmail) return

    try {
      // Создаем запрос на сервер для создания общего доступа
      const response = await fetch("/api/share", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          deviceId,
          ownerEmail: currentUser?.email,
          shareWithEmail: shareEmail,
          permissions: ["read", "authenticate"],
        }),
      })

      if (response.ok) {
        const result = await response.json()
        
        setDevices((prev) =>
          prev.map((device) =>
            device.id === deviceId
              ? {
                  ...device,
                  isShared: true,
                  sharedWith: [...device.sharedWith, shareEmail],
                }
              : device,
        ),
      )

      // Показываем ссылку пользователю
      alert(`Ссылка для доступа: ${result.shareUrl}`)
    } catch (error) 
      console.error("Ошибка создания общего доступа:", error)

    setShareEmail("")
    syncToCloud()
  }

  const syncWithCloud = () => {
    setSyncStatus("syncing")

    setTimeout(() => {
      setSyncStatus("synced")
      setLastSynced(new Date())
    }, 2000)
  }

  const generateWindowsInstaller = async () => {
    try {
      const response = await fetch("/api/download/installer")
      if (response.ok) {
        const blob = await response.blob()
        const url = URL.createObjectURL(blob)
        const a = document.createElement("a")
        a.href = url
        a.download = "CloudSecurityKey_Setup.bat"
        document.body.appendChild(a)
        a.click()
        document.body.removeChild(a)
        URL.revokeObjectURL(url)
      }
    } catch (error) {
      console.error(\"Ошибка скачивания установщика:", error)
    }
  }

  if (!isInstalled) {
    return (
      <div className=\"min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <Card className="w-full max-w-lg">
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center">
              <Cloud className="w-8 h-8 text-white" />
            </div>
            <CardTitle className="text-2xl">Cloud Security Key</CardTitle>
            <CardDescription>Облачный эмулятор USB Security Key для Windows</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <Alert>
              <Shield className="h-4 w-4" />
              <AlertDescription>\
                Это приложение создает виртуальную USB флешку с облачной синхронизацией, которая работает как настоящий
                security key для Google Accounts и других сервисов
              </AlertDescription>
            </Alert>

            {installProgress > 0 && (
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Установка драйвера и облачных компонентов...</span>
                  <span>{Math.round(installProgress)}%</span>
                </div>
                <Progress value={installProgress} />
              </div>
            )}

            <div className="space-y-4">
              <Button onClick={installVirtualDriver} className="w-full" size="lg" disabled={installProgress > 0}>
                <Download className="w-4 h-4 mr-2" />
                {installProgress > 0 ? "Установка..." : "Установить Cloud Security Key"}
              </Button>

              <Button onClick={generateWindowsInstaller} variant="outline" className="w-full">
                <Globe className="w-4 h-4 mr-2" />
                Скачать установщик для Windows
              </Button>
            </div>

            <div className="text-xs text-center text-muted-foreground space-y-1">
              <p>Требования: Windows 10/11, права администратора</p>
              <p>Совместимо с Chrome, Firefox, Edge</p>
              <p>Облачная синхронизация для совместного доступа</p>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center">
              <Cloud className="w-8 h-8 text-white" />
            </div>
            <CardTitle className="text-2xl">Cloud Security Key</CardTitle>
            <CardDescription>Войдите в свой аккаунт для доступа к облачным ключам</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="your@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Пароль</Label>
              <Input
                id="password"
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
          </CardContent>
          <CardFooter>
            <Button onClick={login} className="w-full">
              <LogIn className="w-4 h-4 mr-2" />
              Войти
            </Button>
          </CardFooter>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                  <Cloud className="w-6 h-6 text-white" />
                </div>
                <div>
                  <CardTitle>Cloud Security Key Manager</CardTitle>
                  <CardDescription>Облачное управление виртуальными USB security keys</CardDescription>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <Badge
                  variant={syncStatus === "synced" ? "outline" : "secondary"}
                  className="flex items-center space-x-1"
                >
                  <RefreshCw className={`w-3 h-3 ${syncStatus === "syncing" ? "animate-spin" : ""}`} />
                  <span>
                    {syncStatus === "synced"
                      ? `Синхронизировано ${lastSynced?.toLocaleTimeString()}`
                      : "Синхронизация..."}
                  </span>
                </Badge>

                {isEncrypted && (
                  <Badge variant="default" className="flex items-center space-x-1">
                    <Shield className="w-3 h-3" />
                    <span>Зашифровано</span>
                  </Badge>
                )}

                <Badge
                  variant={
                    cloudStatus === "connected" ? "default" : cloudStatus === "error" ? "destructive" : "secondary"
                  }
                  className="flex items-center space-x-1"
                >
                  <Cloud className="w-3 h-3" />
                  <span>
                    {cloudStatus === "connected"
                      ? "Облако подключено"
                      : cloudStatus === "error"
                        ? "Ошибка облака"
                        : "Облако отключено"}
                  </span>
                </Badge>

                <div className="flex items-center space-x-2">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback>{currentUser?.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div className="text-sm">
                    <p className="font-medium">{currentUser?.name}</p>
                    <p className="text-xs text-muted-foreground">{currentUser?.email}</p>
                  </div>
                </div>
                <Button variant="ghost" size="icon" onClick={logout}>
                  <LogOut className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
        </Card>

        <Tabs defaultValue="devices" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="devices">Устройства ({devices.length})</TabsTrigger>
            <TabsTrigger value="sharing">Общий доступ</TabsTrigger>
            <TabsTrigger value="google">Google Setup</TabsTrigger>
            <TabsTrigger value="settings">Настройки</TabsTrigger>
          </TabsList>

          <TabsContent value="devices" className="space-y-6">
            {/* Device Controls */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Облачные устройства</CardTitle>
                  <div className="flex space-x-2">
                    <Button onClick={syncToCloud} variant="outline" size="sm" disabled={!isEncrypted}>
                      <RefreshCw className="w-4 h-4 mr-2" />
                      Синхронизировать с облаком
                    </Button>
                    <Button onClick={createNewDevice} size="sm">
                      <Usb className="w-4 h-4 mr-2" />
                      Создать устройство
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {devices.map((device) => (
                    <div key={device.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div
                          className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                            device.status === "connected"
                              ? "bg-green-100"
                              : device.status === "authenticating"
                                ? "bg-yellow-100"
                                : "bg-gray-100"
                          }`}
                        >
                          {device.status === "authenticating" ? (
                            <Fingerprint className="w-6 h-6 text-yellow-600 animate-pulse" />
                          ) : device.status === "connected" ? (
                            <CheckCircle className="w-6 h-6 text-green-600" />
                          ) : (
                            <Usb className="w-6 h-6 text-gray-600" />
                          )}
                        </div>
                        <div>
                          <div className="flex items-center space-x-2">
                            <p className="font-medium">{device.name}</p>
                            {device.isShared && (
                              <Badge variant="secondary" className="text-xs">
                                <Users className="w-3 h-3 mr-1" />
                                Общий
                              </Badge>
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground">ID: {device.id}</p>
                          <p className="text-xs text-muted-foreground">
                            Аутентификаций: {device.totalAuth} • Последнее использование:{" "}
                            {device.lastUsed.toLocaleString()}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge
                          variant={
                            device.status === "connected"
                              ? "default"
                              : device.status === "authenticating"
                                ? "secondary"
                                : "outline"
                          }
                        >
                          {device.status === "connected"
                            ? "Подключено"
                            : device.status === "authenticating"
                              ? "Аутентификация"
                              : "Отключено"}
                        </Badge>
                        {device.status === "connected" ? (
                          <Button onClick={() => stopVirtualDevice(device.id)} size="sm" variant="outline">
                            <Square className="w-4 h-4" />
                          </Button>
                        ) : (
                          <Button onClick={() => startVirtualDevice(device.id)} size="sm">
                            <Play className="w-4 h-4" />
                          </Button>
                        )}
                        <Button variant="outline" size="sm">
                          <Share2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="sharing" className="space-y-6">
            {/* Sharing Controls */}
            <Card>
              <CardHeader>
                <CardTitle>Общий доступ к ключам</CardTitle>
                <CardDescription>Предоставьте доступ к вашим виртуальным ключам другим пользователям</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <Input
                      placeholder="Email пользователя"
                      value={shareEmail}
                      onChange={(e) => setShareEmail(e.target.value)}
                    />
                    <Button onClick={() => shareDevice(devices[0]?.id)} disabled={!shareEmail || !devices.length}>
                      <UserPlus className="w-4 h-4 mr-2" />
                      Поделиться
                    </Button>
                  </div>

                  <div className="pt-4 border-t">
                    <h4 className="font-medium mb-3">Пользователи с доступом</h4>
                    {sharedUsers.length > 0 ? (
                      <div className="space-y-3">
                        {sharedUsers.map((user) => (
                          <div key={user.id} className="flex items-center justify-between p-3 border rounded-lg">
                            <div className="flex items-center space-x-3">
                              <Avatar className="h-8 w-8">
                                <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                              </Avatar>
                              <div>
                                <p className="font-medium">{user.name}</p>
                                <p className="text-sm text-muted-foreground">{user.email}</p>
                              </div>
                            </div>
                            <Badge variant="outline">Активен</Badge>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-sm text-muted-foreground">Нет пользователей с доступом</p>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  Ссылка для доступа
                </CardTitle>
                <CardDescription>Поделитесь ссылкой для быстрого доступа к вашим ключам</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-2">
                  <Input 
                    readOnly 
                    value={`${process.env.NEXT_PUBLIC_APP_URL}/share/${currentUser?.id}?key=${devices[0]?.id}`} 
                  />
                  <Button
                    variant="outline"
                    onClick={() => {
                      navigator.clipboard.writeText(
                        `${process.env.NEXT_PUBLIC_APP_URL}/share/${currentUser?.id}?key=${devices[0]?.id}`,
                      )
                    }}
                  >
                    <Copy className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="google" className="space-y-6">
            {/* Google Integration */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <img src="/images/google-passkey.png" alt="Google Passkey" className="w-6 h-6" />
                  <span>Настройка Google Accounts</span>
                </CardTitle>
                <CardDescription>Добавьте виртуальный ключ в Google как security key</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <Alert>
                  <CheckCircle className="h-4 w-4" />
                  <AlertDescription>
                    <strong>Облачное устройство готово!</strong> Теперь Google будет видеть его как настоящую USB
                    флешку, а другие пользователи с доступом смогут использовать его для входа.
                  </AlertDescription>
                </Alert>

                <div className="space-y-4">
                  <div className="p-4 bg-blue-50 rounded-lg">
                    <h4 className="font-medium mb-2">Инструкция для Google Accounts:</h4>
                    <ol className="list-decimal list-inside space-y-2 text-sm">
                      <li>Убедитесь, что виртуальное устройство запущено (зеленый статус)</li>
                      <li>Откройте Google Accounts → Безопасность → Двухэтапная аутентификация</li>
                      <li>Нажмите "Добавить ключ безопасности"</li>
                      <li>Выберите "USB security key"</li>
                      <li>Google автоматически обнаружит виртуальное устройство</li>
                      <li>Следуйте инструкциям на экране</li>
                    </ol>
                  </div>

                  <Button
                    onClick={() => window.open("https://myaccount.google.com/security", "_blank")}
                    className="w-full"
                  >
                    <Key className="w-4 h-4 mr-2" />
                    Открыть Google Security Settings
                  </Button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t">
                  <div className="space-y-2">
                    <h5 className="font-medium">Статус облачной системы:</h5>
                    <Badge variant={systemStatus === "running" ? "default" : "secondary"}>
                      {systemStatus === "running" ? "Готов к работе" : "Ожидание"}
                    </Badge>
                  </div>
                  <div className="space-y-2">
                    <h5 className="font-medium">Активных устройств:</h5>
                    <Badge variant="outline">{devices.filter((d) => d.status === "connected").length}</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Settings className="w-5 h-5" />
                  <span>Настройки приложения</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-base">Автозапуск с Windows</Label>
                      <p className="text-sm text-muted-foreground">Запускать виртуальные ключи при старте системы</p>
                    </div>
                    <Button variant="outline" size="sm">
                      Включить
                    </Button>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-base">Облачная синхронизация</Label>
                      <p className="text-sm text-muted-foreground">Автоматически синхронизировать ключи</p>
                    </div>
                    <Button variant="outline" size="sm">
                      Настроить
                    </Button>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-base">Уведомления</Label>
                      <p className="text-sm text-muted-foreground">Показывать уведомления при аутентификации</p>
                    </div>
                    <Button variant="outline" size="sm">
                      Настроить
                    </Button>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-base">Логирование</Label>
                      <p className="text-sm text-muted-foreground">Сохранять логи аутентификации</p>
                    </div>
                    <Button variant="outline" size="sm">
                      Включить
                    </Button>
                  </div>
                </div>

                <div className="pt-4 border-t space-y-4">
                  <Button onClick={generateWindowsInstaller} variant="outline" className="w-full">
                    <Download className="w-4 h-4 mr-2" />
                    Скачать установщик для Windows
                  </Button>

                  <Button
                    variant="destructive"
                    onClick={() => {
                      if (confirm("Удалить все виртуальные устройства?")) {
                        localStorage.clear()
                        window.location.reload()
                      }
                    }}
                    className="w-full"
                  >
                    Сбросить все настройки
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
