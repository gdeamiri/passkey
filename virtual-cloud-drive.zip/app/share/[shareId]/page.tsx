"use client"

import { useState, useEffect } from "react"
import { useParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Key, Shield, CheckCircle, AlertCircle, Users, Fingerprint, Play, Square, ExternalLink } from "lucide-react"

interface SharedDevice {
  id: string
  name: string
  ownerEmail: string
  permissions: string[]
  status: "available" | "in-use" | "offline"
}

export default function SharedKeyPage() {
  const params = useParams()
  const shareId = params.shareId as string

  const [isLoading, setIsLoading] = useState(true)
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [userEmail, setUserEmail] = useState("")
  const [sharedDevice, setSharedDevice] = useState<SharedDevice | null>(null)
  const [error, setError] = useState("")
  const [deviceStatus, setDeviceStatus] = useState<"disconnected" | "connected" | "authenticating">("disconnected")

  useEffect(() => {
    // Проверяем, есть ли сохраненный email
    const savedEmail = localStorage.getItem("sharedKeyEmail")
    if (savedEmail) {
      setUserEmail(savedEmail)
      authenticateAccess(savedEmail)
    } else {
      setIsLoading(false)
    }
  }, [shareId])

  const authenticateAccess = async (email: string) => {
    setIsLoading(true)
    setError("")

    try {
      const response = await fetch(`/api/share?shareId=${shareId}&userEmail=${email}`)

      if (response.ok) {
        const shareData = await response.json()

        setSharedDevice({
          id: shareData.deviceId,
          name: `Shared Security Key`,
          ownerEmail: shareData.ownerEmail,
          permissions: shareData.permissions,
          status: "available",
        })

        setIsAuthenticated(true)
        localStorage.setItem("sharedKeyEmail", email)
      } else {
        const errorData = await response.json()
        setError(errorData.error || "Доступ запрещен")
      }
    } catch (error) {
      setError("Ошибка подключения к серверу")
    } finally {
      setIsLoading(false)
    }
  }

  const handleLogin = () => {
    if (!userEmail.trim()) {
      setError("Введите ваш email")
      return
    }
    authenticateAccess(userEmail)
  }

  const startVirtualDevice = () => {
    setDeviceStatus("connected")

    // Симуляция работы устройства
    setTimeout(() => {
      setDeviceStatus("authenticating")

      setTimeout(() => {
        setDeviceStatus("connected")
      }, 3000)
    }, 2000)
  }

  const stopVirtualDevice = () => {
    setDeviceStatus("disconnected")
  }

  const openGoogleSecurity = () => {
    window.open("https://myaccount.google.com/security", "_blank")
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardContent className="flex items-center justify-center p-8">
            <div className="text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
              <p>Загрузка общего ключа...</p>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center">
              <Users className="w-8 h-8 text-white" />
            </div>
            <CardTitle className="text-2xl">Доступ к общему ключу</CardTitle>
            <CardDescription>Введите ваш email для доступа к общему security key</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {error && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="your@email.com"
                value={userEmail}
                onChange={(e) => setUserEmail(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleLogin()}
              />
            </div>

            <Button onClick={handleLogin} className="w-full">
              <Key className="w-4 h-4 mr-2" />
              Получить доступ
            </Button>

            <div className="text-xs text-center text-muted-foreground">Ссылка: {shareId}</div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                  <Users className="w-6 h-6 text-white" />
                </div>
                <div>
                  <CardTitle>Общий Security Key</CardTitle>
                  <CardDescription>Доступ предоставлен: {sharedDevice?.ownerEmail}</CardDescription>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Avatar className="h-8 w-8">
                  <AvatarFallback>{userEmail.charAt(0).toUpperCase()}</AvatarFallback>
                </Avatar>
                <div className="text-sm">
                  <p className="font-medium">{userEmail}</p>
                </div>
              </div>
            </div>
          </CardHeader>
        </Card>

        {/* Device Status */}
        <Card>
          <CardHeader>
            <CardTitle>Статус виртуального ключа</CardTitle>
            <CardDescription>Управление общим security key для аутентификации</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div className="flex items-center space-x-4">
                <div
                  className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                    deviceStatus === "connected"
                      ? "bg-green-100"
                      : deviceStatus === "authenticating"
                        ? "bg-yellow-100"
                        : "bg-gray-100"
                  }`}
                >
                  {deviceStatus === "authenticating" ? (
                    <Fingerprint className="w-6 h-6 text-yellow-600 animate-pulse" />
                  ) : deviceStatus === "connected" ? (
                    <CheckCircle className="w-6 h-6 text-green-600" />
                  ) : (
                    <Key className="w-6 h-6 text-gray-600" />
                  )}
                </div>
                <div>
                  <p className="font-medium">{sharedDevice?.name}</p>
                  <p className="text-sm text-muted-foreground">ID: {sharedDevice?.id}</p>
                  <div className="flex items-center space-x-2 mt-1">
                    {sharedDevice?.permissions.map((permission) => (
                      <Badge key={permission} variant="outline" className="text-xs">
                        {permission === "read"
                          ? "Просмотр"
                          : permission === "authenticate"
                            ? "Аутентификация"
                            : permission}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Badge
                  variant={
                    deviceStatus === "connected"
                      ? "default"
                      : deviceStatus === "authenticating"
                        ? "secondary"
                        : "outline"
                  }
                >
                  {deviceStatus === "connected"
                    ? "Подключено"
                    : deviceStatus === "authenticating"
                      ? "Аутентификация"
                      : "Отключено"}
                </Badge>
                {deviceStatus === "connected" ? (
                  <Button onClick={stopVirtualDevice} size="sm" variant="outline">
                    <Square className="w-4 h-4" />
                  </Button>
                ) : (
                  <Button onClick={startVirtualDevice} size="sm">
                    <Play className="w-4 h-4" />
                  </Button>
                )}
              </div>
            </div>

            {deviceStatus === "connected" && (
              <Alert>
                <CheckCircle className="h-4 w-4" />
                <AlertDescription>
                  <strong>Виртуальный ключ активен!</strong> Теперь вы можете использовать его для входа в Google
                  Accounts и другие сервисы.
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>

        {/* Google Integration */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <img src="/images/google-passkey.png" alt="Google Passkey" className="w-6 h-6" />
              <span>Использование с Google Accounts</span>
            </CardTitle>
            <CardDescription>Добавьте общий ключ в Google как security key</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-4 bg-blue-50 rounded-lg">
              <h4 className="font-medium mb-2">Инструкция:</h4>
              <ol className="list-decimal list-inside space-y-2 text-sm">
                <li>Убедитесь, что виртуальный ключ запущен (зеленый статус)</li>
                <li>Откройте Google Accounts → Безопасность → Двухэтапная аутентификация</li>
                <li>Нажмите "Добавить ключ безопасности"</li>
                <li>Выберите "USB security key"</li>
                <li>Google автоматически обнаружит виртуальный ключ</li>
                <li>Следуйте инструкциям на экране</li>
              </ol>
            </div>

            <Button onClick={openGoogleSecurity} className="w-full">
              <ExternalLink className="w-4 h-4 mr-2" />
              Открыть Google Security Settings
            </Button>
          </CardContent>
        </Card>

        {/* Security Info */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Shield className="w-5 h-5" />
              <span>Информация о безопасности</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <h5 className="font-medium">Владелец ключа:</h5>
                <p className="text-sm text-muted-foreground">{sharedDevice?.ownerEmail}</p>
              </div>
              <div className="space-y-2">
                <h5 className="font-medium">Ваши разрешения:</h5>
                <div className="flex space-x-1">
                  {sharedDevice?.permissions.map((permission) => (
                    <Badge key={permission} variant="outline" className="text-xs">
                      {permission === "read"
                        ? "Просмотр"
                        : permission === "authenticate"
                          ? "Аутентификация"
                          : permission}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>

            <Alert>
              <Shield className="h-4 w-4" />
              <AlertDescription>
                Этот ключ предоставлен вам для совместного использования. Все действия логируются для безопасности.
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
